nums = [2, 5, 6, 8, 11]
numsquares = []

for num in nums:
    numsquares.append(num ** 2)

print(numsquares)
