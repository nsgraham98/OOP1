ages = {'Tom': 56, 'Joe': 61, 'Maria': 55}

for person, age in ages.items():
    print(f"{person} is {age} years old.")

