    
x = "Nicholas Graham"
print("the type of x is", type(x))
x = 25 + 5
print("the type of x is", type(x))
x = 25.5
print("the type of x is", type(x))
x = True
print("the type of x is", type(x))

from typing import Final
    # constant - XYZ:Final = 100 
    # use uppercase 
    # constants are usually created in a new module/file (eg. constants.py)
GST:Final = 0.05
KG_TO_LB:Final = 2.2
PI:Final = 3.14159

