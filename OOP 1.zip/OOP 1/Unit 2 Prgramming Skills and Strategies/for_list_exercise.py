mph = range(10, 71)

for mph in range(10, 71, 10):
    print(f"mph = {mph}, \t kph = {mph * 1.61}")