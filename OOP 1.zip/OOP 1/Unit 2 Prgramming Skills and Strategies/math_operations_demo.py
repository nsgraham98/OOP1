x = 21
y = 10
z = 0
z = x+y
print("the value of z is:", z)
z= x-y
print("the value of z is:", z)
z=x*y
print("the value of z is:", z)
z=x//y
print("the value of z is:", z)
z=x**y
print("the value of z is:", z)
z=x%y
print("the value of z is:", z)

r = 4/2+8*4-(5+2)%3
print(r)

t = 3*(4+2)-18/3+5**2
print(t)



# "n = n+3" is the same as "n +=3"
n = 5
n += 3
print(n)

m = 5
m -= 3
print(m)

p = 5
p *= 3
print(p)

# getting integer input (changing from string)
