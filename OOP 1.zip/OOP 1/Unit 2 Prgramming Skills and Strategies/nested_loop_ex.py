for i in range (1, 3):
    for j in range(1,3):
        for k in range(1,3):
            print(i, j, k)
