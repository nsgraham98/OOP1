num = 12
if (num >= 0):
    print(f'The {num} is positive')
else:
    print(f"The {num} is negative")
