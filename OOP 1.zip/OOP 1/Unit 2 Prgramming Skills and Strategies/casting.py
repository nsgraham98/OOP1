x = 10
print("Type of x is", type(x))
print("The value of x is", x)
y = float(x)
print("Type of y is", type(y))
print("The value of y is", y)

