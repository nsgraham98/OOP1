weekdays = ("sun", "mon", "tue", "wed", "thu", "fri", "sat")

print(weekdays)

print(weekdays[1:6])
print(weekdays[::6])
