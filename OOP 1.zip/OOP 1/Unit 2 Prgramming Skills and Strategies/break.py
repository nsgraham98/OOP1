for number in range(100):
    if number == 10:
        break
    print(number, end=" ")
