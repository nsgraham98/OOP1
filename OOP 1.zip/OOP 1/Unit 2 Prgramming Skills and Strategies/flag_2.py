for i in range(5):
    n = int(input("Enter a number: "))
    if (n > 2000):
        big_number_flag = True
if (big_number_flag):
    print("BIG NUMBER")