age = int(input("what is your age?"))

if (age >=18):
    print(f"your age is {age}, so you are an adult")
else:
    print(f"your age is {age}, so you are a minor")