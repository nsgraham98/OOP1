user_age = int(input('Enter Age:'))
if (user_age >= 18) and (user_age <= 25):
    print('Eligible')
else:
    print('Ineligible')
