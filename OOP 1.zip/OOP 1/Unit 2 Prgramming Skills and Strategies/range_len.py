str_1 = "Hello world!"

print(len(str_1))

# index [1-12]
for index in range(0, len(str_1)):
    print(str_1[index], end=" ")
    # end=" " to add space after letters
