num = int(input("What is your number?"))

if (num >= 0):
    print(f"{num} is absolute")
else:
    print(f"{num} is not absolute")

if ((num%2) == 0):
    print(f"{num} is even")
else:
    print(f"{num} is odd")
