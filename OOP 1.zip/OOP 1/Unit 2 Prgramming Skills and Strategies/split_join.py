text = ['Python', 'is', 'a', 'fun', 'programming', 'language']
print(text)
# join elements of text with space
text_join = ' '.join(text)
print(text_join)
# # Split elements of text
text_split = text_join.split()
print(text_split)
