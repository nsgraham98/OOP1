num1 = int(input("Input a number: \n"))
num2 = int(input("Input a number: \n"))

if(num1 < num2):
    pass
else:
     print("num2 is greater than num1")
