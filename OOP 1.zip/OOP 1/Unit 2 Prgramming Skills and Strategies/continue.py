number = 0
while number < 10:
    if number == 5:
        number += 1 
        continue
    print(number, end=' ')
    number += 1 