# ESCAPE CHARACTERS
# using "illegal" characters in strings
print("Welcome to \nSAIT")
print("Welcome to \"SAIT\"")
print("Welcome to \\SAIT\\")

