# trapezoid area = (base + base) * h / 2
base = input("What is the length of the base? ")
height = input("What is the height? ")

base = float(base)
height = float(height)

area = base * 2 * height / 2

print(f"The area is {area}.")
