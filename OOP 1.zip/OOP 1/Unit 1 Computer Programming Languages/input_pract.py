# converting str to int
# age = input("What is your age?")
# print(type(age))
# age = int(age)
# age += 10
# print(age)

# converting int to float
height = input("What is your height?")
print(type(height))
height = float(height)
height += 10
print(height)

