Some_number = 0
i = 1

while i < 11:
    Some_number += i
    i += 1
print(Some_number)
