def print_price(product_name, price):
    print(f"The price of {product_name} is {price:.2f}")
    
print_price(product_name="ABC", price=11.95)
print_price(price=11.95,product_name="ABC")
