# var = lambda | argument: expression

add_two_nums = lambda a, b: a + b

print(add_two_nums(4, 5))

#output: 9

print(add_two_nums(10, 20))

# output: 30


area_circle = lambda r: r**2 * 3.14 

# print(area_circle( r ))
print(area_circle(10))

# output: 314.0