import calculator

# calculator.py functions: add(num1, num2), subtract(num1, num2), divide(num1, num2), multiply(num1, num2)

print(calculator.add(1, 2))
print(calculator.subtract(5, 4))
print(calculator.multiply(2, 4))
print(calculator.divide(4, 2))