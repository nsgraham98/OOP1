def cube(num):
    return num ** 3

print(cube(2))
print(cube(3))
print(cube(4))
print(cube(123453234))

def power(base, expo):
    return base ** expo

print(power(3, 4))
print(power(2, 6))