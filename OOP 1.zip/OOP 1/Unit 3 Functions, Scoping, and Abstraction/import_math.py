import math

sqrt_num = math.sqrt(16)
print(sqrt_num)

# print(dir(math))
# print(help(math))