# volume of cube = side^3

length = 4
volume = length ** 3

print(f"The volume of the cube is {volume}cm^3.")