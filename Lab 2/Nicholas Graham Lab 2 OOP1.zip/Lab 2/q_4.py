# circumferece = 2 pi r
# area = pi r^2

r = 2
circumference = 2 * 3.14 * r
area = 3.14 * r ** 2 

print(f"The circumference is {circumference}cm., and the area is {area}cm^2.")
