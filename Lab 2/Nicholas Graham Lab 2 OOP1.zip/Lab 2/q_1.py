name = input("What is your first and last name? ")
age = input("How old are you? ")         
gpa = input("What is your GPA? ")
major = input("What is your major? ")
address = input("What is your address? ")

print(f"Welcome {name}! Your age: {age}, your GPA: {gpa}, your major: {major}, and your address: {address}.")