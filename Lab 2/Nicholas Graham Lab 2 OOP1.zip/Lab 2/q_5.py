total_sum = 1 + 2 + 3 + 4 + 5
average_of_sum = total_sum / 5

print(average_of_sum)